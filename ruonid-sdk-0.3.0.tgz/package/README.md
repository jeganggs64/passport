# @ruonid/sdk

Developer SDK for RuonID identity verification. Integrate privacy-preserving identity checks or free sybil resistance into any app.

## Install

```bash
npm install @ruonid/sdk
```

## Quick start

### Initialize the SDK

```typescript
import { RuonID } from '@ruonid/sdk';

// One-time keypair generation — store the private key securely (env var, secrets manager).
// The public key is your developer identifier — register it with the RuonID dashboard.
const { publicKey, privateKey } = RuonID.generateKeypair();
```

```typescript
// Creates an SDK client. All API calls are authenticated by signing requests with your private key.
const ruonid = new RuonID(process.env.RUONID_PRIVATE_KEY!);
```

### Register as a developer

Register at [ruonlabs.com/developers](https://ruonlabs.com/developers) — choose Sybil Resistance (instant) or Identity Verification (requires admin approval). To upgrade from Sybil Resistance to Identity Verification, visit [ruonlabs.com/developers](https://ruonlabs.com/developers).

### Key rotation

Rotate your keypair without disrupting your users' app-specific IDs:

```typescript
const newPrivateKey = '0x...'; // Your new secp256k1 private key
await ruonid.rotateKey(newPrivateKey);
// SDK now uses the new key for all subsequent requests.
// Drain in-flight requests before rotating.
```

The rotation is authenticated with dual signatures (old + new key) and a server-issued nonce.

### Free sybil resistance

Verify unique personhood without collecting any personal information. Each user gets an anonymous app-specific ID that's consistent across sessions but can't be correlated across developers.

All callbacks are **ECIES-encrypted** — the app encrypts the payload with your public key, and the SDK decrypts it with your private key. Even the anonymous `appSpecificId` is never sent in cleartext.

```typescript
// 1. Create a session payload
const session = ruonid.createVerifySession('https://myapp.com/api/check');

// 2. Present to the user — either as a QR code or a universal link
const qrData = RuonID.toUniversalLink(session);

// 3. Handle the encrypted callback on your server
// The RuonID app ECIES-encrypts the result with your public key and POSTs it.
// The SDK decrypts, verifies the signature, and returns the clean data.
app.post('/api/check', async (req, res) => {
  try {
    const { appSpecificId, deviceVerified, receipt } = await ruonid.handleVerifyCallback(req.body);
    // appSpecificId: deterministic anonymous hex string (0x + 64 chars)
    // deviceVerified: true if device attestation passed
    // receipt: server-signed proof of attestation
    res.json({ ok: true, userId: appSpecificId });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
```

### Full identity verification

Get encrypted PII — name, nationality, date of birth, passport photo, etc. The user sees a consent screen listing exactly which fields you're requesting. Request production access at [ruonlabs.com/developers](https://ruonlabs.com/developers).

```typescript
// 1. Create a signed session
const session = ruonid.createSession('https://myapp.com/api/verify', {
  requestedFields: ['name', 'nationality', 'dateOfBirth'],
});

// 2. Present to the user as a QR code or universal link
const qrData = RuonID.toUniversalLink(session);

// 3. Handle the encrypted callback
// The RuonID app encrypts the identity data with your public key (ECIES + AES-256-GCM)
// and POSTs it to your callback URL. Only your private key can decrypt it.
app.post('/api/verify', async (req, res) => {
  try {
    // Pass the session ID to verify it matches the original request.
    // This prevents replay attacks from a different session.
    const identity = await ruonid.handleCallback(req.body, session.sessionId);
    console.log(identity.appSpecificId);  // "0xabc..." — anonymous user ID
    console.log(identity.name);           // "John Doe"
    console.log(identity.nationality);    // "US"
    console.log(identity.dateOfBirth);    // "1990-01-15"
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
```

### Identity migration

When a user renews their passport or upgrades their identity tier, their app-specific ID changes. The migration flow lets them link their old ID to their new one so you can update your records.

```typescript
// 1. Generate a migration session
const session = ruonid.createMigrationSession('https://myapp.com/api/migrate');
const qrData = RuonID.toUniversalLink(session);

// 2. Handle the encrypted migration callback
// Same ECIES encryption as all other flows.
app.post('/api/migrate', async (req, res) => {
  try {
    const { oldAppSpecificId, newAppSpecificId, receipt } = await ruonid.handleMigrationCallback(req.body);
    // Both IDs verified to belong to the same person.
    // Update your database: oldAppSpecificId → newAppSpecificId
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
```

## API reference

### `RuonID` class

```typescript
new RuonID(privateKey: string)
```

Creates an SDK client. The private key is your secp256k1 key (hex). All API requests are authenticated by signing with this key.

| Method | Description |
|---|---|
| `getProfile()` | Get your developer profile |
| `getUsage()` | Get your usage statistics |
| `rotateKey(newPrivateKey)` | Rotate your keypair (signs with both old and new keys) |
| `sandboxSimulate(session)` | Send a session to the sandbox endpoint |
| `billingCheckout(params?)` | Create a Stripe billing checkout session |
| `createVerifySession(callbackUrl, options?)` | Create a payload for free sybil resistance (returns `VerifyQRPayload`) |
| `handleVerifyCallback(body)` | Decrypt and validate the verify callback, returns `{ appSpecificId, deviceVerified, receipt }` |
| `createSession(callbackUrl, options?)` | Create a signed payload for full identity verification (returns `QRPayload`) |
| `handleCallback(body, sessionId?)` | Decrypt and validate the identity callback (returns `DecryptedIdentity`) |
| `createMigrationSession(callbackUrl, options?)` | Create a payload for identity migration (returns `MigrationQRPayload`) |
| `handleMigrationCallback(body)` | Decrypt and validate migration, returns `{ oldAppSpecificId, newAppSpecificId, receipt }` |
| `static generateKeypair()` | Generate a new secp256k1 keypair |
| `static setServerPublicKey(key)` | Set the server's public key for receipt verification |
| `static fetchServerSigningKey(url)` | Fetch and cache the server's signing key from JWKS |

### Standalone functions

All methods on `RuonID` are also available as standalone functions:

```typescript
import {
  generateKeypair,
  createSession,
  createVerifySession,
  createMigrationSession,
  toUniversalLink,
  handleCallback,
  handleVerifyCallback,
  handleMigrationCallback,
  decryptIdentity,
  verifyResponse,
  verifyHashSig,
  verifyHash,
  fetchServerSigningKey,
} from '@ruonid/sdk';
```

### Types

```typescript
interface VerifyQRPayload {
  type: "verify";
  sessionId: string;            // Unique session ID
  timestamp: number;            // Unix timestamp (ms)
  sessionProof: string;         // secp256k1 signature over the payload
  developerPublicKey: string;   // Your secp256k1 public key (hex)
  callbackUrl: string;          // Where the RuonID app POSTs the result
}

interface MigrationQRPayload {
  type: "migrate";
  sessionId: string;            // Unique session ID
  timestamp: number;            // Unix timestamp (ms)
  sessionProof: string;         // secp256k1 signature over the payload
  developerPublicKey: string;   // Your secp256k1 public key (hex)
  callbackUrl: string;          // Where the RuonID app POSTs the result
}

interface QRPayload {
  sessionId: string;            // Unique session ID (UUID v4)
  timestamp: number;            // Unix timestamp (ms)
  sessionProof: string;         // secp256k1 signature over the payload
  developerPublicKey: string;   // Your secp256k1 public key (hex)
  callbackUrl: string;          // Where the RuonID app POSTs encrypted identity
  requestedFields?: string[];   // Fields shown on the user's consent screen
  // Available fields: name, nationality, dateOfBirth, natIdNumber,
  // countryCode, documentNumber, expiryDate, passportPhoto
}

interface VerifyCallback {
  appSpecificId: string;        // 0x + 64 hex chars — unique per developer
  identityTier?: IdentityTier;  // "unique" or "passport-bound"
  deviceVerified?: boolean;     // Whether device passed attestation
  receipt?: VerifiedReceipt;    // Server-signed attestation receipt
}

interface DecryptedIdentity {
  appSpecificId: string;        // Anonymous user ID (unique per developer)
  sessionId: string;            // Matches the original session
  identityTier?: IdentityTier;  // "unique" (national ID) or "passport-bound"
  name?: string;
  nationality?: string;
  dateOfBirth?: string;
  natIdNumber?: string;
  countryCode?: string;
  documentNumber?: string;
  expiryDate?: string;          // Passport expiry date (YYMMDD)
  passportPhoto?: string;       // Base64 JPEG from passport NFC chip (requires verified developer)
  verifiedAt?: number;          // Unix timestamp of verification
  receipt?: VerifiedReceipt;    // Server-signed attestation receipt
}

interface MigrationCallback {
  oldAppSpecificId: string;     // Previous app-specific ID
  newAppSpecificId: string;     // Updated app-specific ID
  identityTier?: IdentityTier;
  receipt?: VerifiedReceipt;    // Proof both IDs belong to the same person
}

type IdentityTier = "unique" | "passport-bound";
```

## Encryption

All three callback flows (sybil, identity, migration) use the same **ECIES + AES-256-GCM** encryption. The RuonID app generates a fresh AES-256 key, encrypts the payload, then encrypts the AES key under your secp256k1 public key via ECIES. The callback body contains `{ encryptedBlob, encryptedKey, userPublicKey, signature }` — no plaintext data is ever transmitted. The SDK's `handle*Callback` methods decrypt and verify automatically using your private key.

## Server receipts

Every callback from the RuonID app includes a **server-signed receipt** proving the RuonID server verified the user's device attestation (App Attest on iOS, Play Integrity on Android). The SDK automatically:

1. **Verifies the receipt signature** (`verifyHashSig`) — fetches the server's signing key from the JWKS endpoint (`https://api.ruonlabs.com/.well-known/jwks.json`) and verifies the secp256k1 KMS signature.
2. **Verifies the payload hash** (`verifyHash`) — hashes the callback data and checks it matches the `payloadHash` in the receipt, proving the receipt is bound to this specific response.

If either check fails, the callback handler throws. No manual setup required.

Both functions are also exported for manual use:

```typescript
import { verifyHashSig, verifyHash } from '@ruonid/sdk';

// Verify the KMS signature on the receipt
const sigValid = verifyHashSig(receipt);

// Verify the payload hash matches the callback data
const hashValid = verifyHash(receipt, callbackBody);
```

### Manual receipt verification (without the SDK)

If you're verifying receipts without this SDK (e.g., in a different language), note that the RuonID server uses **AWS KMS** for signing, which can produce **high-S** ECDSA signatures. Many secp256k1 libraries (including `@noble/curves`) enforce low-S by default ([BIP-146](https://github.com/bitcoin/bips/blob/master/bip-0146.mediawiki)) and will reject these signatures.

To handle this, **disable low-S enforcement** when verifying:

```typescript
import { secp256k1 } from '@noble/curves/secp256k1';

// Pass lowS: false to accept both high-S and low-S signatures from KMS
const valid = secp256k1.verify(signatureBytes, messageHash, publicKeyBytes, { lowS: false });
```

The SDK's built-in `verifyHashSig()` handles this automatically.

## Sandbox testing

Test your integration without a real user or the RuonID app. The sandbox endpoint accepts the same session payloads the SDK produces and sends a properly encrypted callback to your server — matching the exact production format.

**Prerequisites**: Register via `ruonid.register('Company Name')` to get sandbox access (instant).

```typescript
const ruonid = new RuonID(process.env.RUONID_PRIVATE_KEY!);

// 1. Create a session — same code as production
const session = ruonid.createSession('https://myapp.com/api/verify', {
  requestedFields: ['name', 'nationality', 'dateOfBirth'],
});

// 2. Instead of showing a QR code, send it to the sandbox endpoint
await ruonid.sandboxSimulate(session);

// 3. Your callback URL receives the response — handle it exactly like production
app.post('/api/verify', async (req, res) => {
  const identity = await ruonid.handleCallback(req.body);
  console.log(identity.name);        // "Oliver Brown" (fake data)
  console.log(identity.nationality); // "United Kingdom"
  console.log(identity.dateOfBirth); // "1986-09-15"
});
```

All three flows work in sandbox:

```typescript
// Sybil resistance
const verifySession = ruonid.createVerifySession(callbackUrl);
await ruonid.sandboxSimulate(verifySession);

// Identity verification
const identitySession = ruonid.createSession(callbackUrl, { requestedFields: ['name', 'nationality'] });
await ruonid.sandboxSimulate(identitySession);

// Migration
const migrateSession = ruonid.createMigrationSession(callbackUrl);
await ruonid.sandboxSimulate(migrateSession);
```

Sandbox callbacks include `sandbox: true` so you can distinguish them from production. Signatures are valid and encrypted blobs decrypt with your private key — test your full pipeline end-to-end.

## App-specific IDs

Every user gets a unique ID per developer: `SHA256(ruonId || developerId)`. This means:

- **Same user, same developer** → same ID (consistent across sessions, stable across key rotations)
- **Same user, different developer** → different ID (can't track users across apps)
- **The raw `ruonId` never leaves the user's device**

## License

MIT
